public class Prevalent {

    public static Users currentOnlineUser;

    public static final String UserRegistrationKey="UserRegitration";
    public static final String UserPasswordKey="UserPassword";
}
